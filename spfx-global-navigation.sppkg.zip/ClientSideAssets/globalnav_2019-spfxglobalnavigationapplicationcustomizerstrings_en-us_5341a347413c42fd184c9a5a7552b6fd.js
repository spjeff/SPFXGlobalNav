define([], function() {
  return {
    "Title": "SpfxGlobalNavigationApplicationCustomizer"
  }
});